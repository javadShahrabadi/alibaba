module.exports = {
  reactStrictMode: true,
  images: {
    domains: ["cdn.alibaba.ir"],
  },
};
