const Header = () => {
  return (
    <div>
      <img
        src="https://cdn.alibaba.ir/h/desktop/assets/images/hero/hero-518e7e11.webp"
        alt="header-plane-img"
        className="object-cover h-[356px]"
      />
    </div>
  );
};

export default Header;
